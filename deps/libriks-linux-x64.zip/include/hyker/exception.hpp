#ifndef HYKER_EXCEPTION_HPP
#define HYKER_EXCEPTION_HPP

#ifndef _GLIBCXX_USE_CXX11_ABI
#define HYKER_CXX11_ABI 1
#define _GLIBCXX_USE_CXX11_ABI 0
#endif

// std
#include <stdexcept>
#include <string>

namespace hyker {
    class Exception : public std::runtime_error {
    public:
        Exception(const std::string& what) : std::runtime_error(what) {}
    };

    class IOException : public Exception {
    public:
        IOException(const std::string& what) : Exception(what) {}
    };

    class FileNotFoundException : public IOException {
    public:
        FileNotFoundException(const std::string& what) : IOException(what) {}
    };

    class NoSuchElementException : public Exception {
    public:
        NoSuchElementException() : NoSuchElementException("No such element.") {}
        NoSuchElementException(const std::string& what) : Exception(what) {}
    };

    class IllegalArgumentException : public Exception {
    public:
        IllegalArgumentException() : IllegalArgumentException("Illegal argument.") {}
        IllegalArgumentException(const std::string& what) : Exception(what) {}
    };

    class IllegalStateException : public Exception {
    public:
        IllegalStateException() : IllegalStateException("Illegal state.") {}
        IllegalStateException(const std::string& what) : Exception(what) {}
    };
}

#ifdef HYKER_CXX11_ABI
#undef _GLIBCXX_USE_CXX11_ABI
#endif
#endif