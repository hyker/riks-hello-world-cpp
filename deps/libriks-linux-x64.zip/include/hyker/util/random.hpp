#ifndef HYKER_UTIL_RANDOM_HPP
#define HYKER_UTIL_RANDOM_HPP

#ifndef _GLIBCXX_USE_CXX11_ABI
#define HYKER_CXX11_ABI 1
#define _GLIBCXX_USE_CXX11_ABI 0
#endif

// std
#include <string>

namespace hyker {
    namespace util {
        namespace random {
            std::string generateString(int length, const std::string&character_set = "abcdefghijklmnopqrstuvwzyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
        }
    }
}

#ifdef HYKER_CXX11_ABI
#undef _GLIBCXX_USE_CXX11_ABI
#endif
#endif