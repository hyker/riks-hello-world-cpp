#ifndef HYKER_UTIL_FILE_HPP
#define HYKER_UTIL_FILE_HPP

#ifndef _GLIBCXX_USE_CXX11_ABI
#define HYKER_CXX11_ABI 1
#define _GLIBCXX_USE_CXX11_ABI 0
#endif

// std
#include <string>

namespace hyker {
    namespace util {
        std::string getPath(const std::string& directory, const std::string& file);
    };
};

#ifdef HYKER_CXX11_ABI
#undef _GLIBCXX_USE_CXX11_ABI
#endif
#endif