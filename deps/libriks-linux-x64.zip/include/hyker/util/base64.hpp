#ifndef HYKER_UTIL_BASE64_HPP
#define HYKER_UTIL_BASE64_HPP

#ifndef _GLIBCXX_USE_CXX11_ABI
#define HYKER_CXX11_ABI 1
#define _GLIBCXX_USE_CXX11_ABI 0
#endif

// std
#include <string>

namespace hyker {
    namespace util {
        namespace base64 {
            std::string decode(std::string data);
            std::string encode(const std::string &data);
        }
    }
}

#ifdef HYKER_CXX11_ABI
#undef _GLIBCXX_USE_CXX11_ABI
#endif
#endif